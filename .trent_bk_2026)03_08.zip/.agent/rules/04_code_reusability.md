# Code Reusability & DRY Enforcement

## Core Principle: The 3-Strike Rule

**If identical or near-identical logic appears 3+ times across files, extraction to a shared module is MANDATORY — not optional.**

Two occurrences = warning. Three occurrences = extract immediately.

## Shared Module Folder Conventions

### TypeScript / JavaScript
```
src/lib/          ← primary shared module root
  utils/          ← pure utility functions
  services/       ← API clients, external integrations
  hooks/          ← React/framework hooks
  components/     ← shared UI components
  types/          ← shared types, interfaces, DTOs, enums
  config/         ← constants, env config, feature flags
  index.ts        ← barrel export

# Monorepo projects
packages/shared/  ← cross-package shared logic
```

### Python
```
lib/              ← primary shared module root
  utils/          ← pure utility functions
  services/       ← API clients, external integrations
  models/         ← shared data models, dataclasses
  types/          ← type aliases, TypedDicts, enums
  config/         ← constants, settings, env parsing
  __init__.py     ← barrel export

# Package-based projects
shared/           ← alternative root when lib/ is taken
```

### General (Any Language)
```
libs/             ← shared libraries
shared/           ← shared utilities
common/           ← common components
```

**Barrel exports are required**: Every shared folder MUST have an `index.ts` or `__init__.py` that re-exports public symbols for clean import paths.

## Reusability Tiers

| Tier | What Belongs Here | Folder |
|------|-------------------|--------|
| **Utilities** | String manipulation, date formatting, validation, math helpers | `lib/utils/` |
| **Services** | API clients, database helpers, auth, logging, caching | `lib/services/` |
| **Components** | Buttons, forms, modals, layout primitives | `lib/components/` |
| **Types** | Shared interfaces, DTOs, enums, type aliases | `lib/types/` |
| **Hooks** | Data fetching hooks, state hooks, event hooks | `lib/hooks/` |
| **Config** | App constants, environment config, feature flags | `lib/config/` |

## Anti-Patterns to Flag (IMMEDIATELY)

### 🔴 Copy-Pasted Logic
```python
# ❌ WRONG — same validation in 3 files
def create_user():
    if len(email) < 3 or '@' not in email:
        raise ValueError("Invalid email")

def update_user():
    if len(email) < 3 or '@' not in email:  # DUPLICATE
        raise ValueError("Invalid email")

# ✅ CORRECT — extracted to shared module
# lib/utils/validators.py
def validate_email(email: str) -> bool:
    return len(email) >= 3 and '@' in email
```

### 🔴 Inline Utility Functions
```typescript
// ❌ WRONG — utility defined inline in component
function UserCard({ user }) {
  const formatName = (first, last) => `${first} ${last}`.trim();
  return <div>{formatName(user.firstName, user.lastName)}</div>;
}

// ✅ CORRECT — utility in shared module
// lib/utils/formatting.ts
export const formatFullName = (first: string, last: string): string =>
  `${first} ${last}`.trim();
```

### 🔴 Fat Components / Classes (Mixed Concerns)
```python
# ❌ WRONG — one class doing everything
class UserController:
    def validate_email(self): ...       # should be in utils
    def hash_password(self): ...        # should be in services/auth
    def send_welcome_email(self): ...   # should be in services/email
    def format_response(self): ...      # should be in utils

# ✅ CORRECT — composed from focused modules
class UserController:
    def __init__(self, auth_service, email_service):
        self._auth = auth_service
        self._email = email_service
```

### 🔴 Hardcoded Values That Should Be Constants
```typescript
// ❌ WRONG
if (retryCount > 3) { ... }
setTimeout(callback, 5000);

// ✅ CORRECT — lib/config/constants.ts
export const MAX_RETRY_COUNT = 3;
export const REQUEST_TIMEOUT_MS = 5000;
```

### 🔴 Re-Implementing Standard Library Functionality
```python
# ❌ WRONG — manual date parsing when stdlib exists
def parse_date(s):
    parts = s.split('-')
    return {'year': parts[0], 'month': parts[1], 'day': parts[2]}

# ✅ CORRECT
from datetime import date
parsed = date.fromisoformat(s)
```

## Metrics & Thresholds

| Metric | Warning | Violation (MANDATORY action) |
|--------|---------|-------------------------------|
| Duplicate logic occurrences | 2 occurrences | 3+ occurrences → extract NOW |
| Shared module consumers | 1 consumer | 0 consumers → delete or wait |
| Function length | > 30 lines | > 50 lines → decompose |
| File importing 0 shared modules | Review if project has shared modules | Flag if clearly reinventing |
| Inline utility function | Suggest extraction | 3+ uses → extract MANDATORY |

**Premature abstraction guard**: New shared modules MUST have 2+ consumers at creation time, OR be clearly planned for immediate reuse. Don't create shared modules for single-use code.

## Before Writing New Code: Mandatory Checklist

```
□ Does a shared module already exist for this logic?
  → Search lib/, shared/, utils/ before writing new code

□ Can this logic be generalized for reuse?
  → If yes, write it in the shared module first

□ Am I duplicating logic from another file?
  → Check existing files for similar implementations

□ Are my utility functions in the right place?
  → Utility functions go in lib/utils/, NOT inline

□ Are my constants defined centrally?
  → Magic numbers/strings go in lib/config/constants
```

## Extraction Process (When 3-Strike Rule Triggers)

1. **Identify** all occurrences of the duplicated logic
2. **Generalize** the implementation (remove caller-specific coupling)
3. **Create or update** the appropriate shared module file
4. **Add barrel export** to `index.ts` / `__init__.py`
5. **Replace** all occurrences with imports from shared module
6. **Verify** no regressions (run tests or manual check)

## Shared Module Quality Standards

- **Single responsibility**: Each module does one thing well
- **Pure functions preferred**: No side effects in utility functions
- **Documented**: Public functions have docstrings/JSDoc comments
- **Tested**: Shared modules should have unit tests (they're used everywhere)
- **Versioned**: Breaking changes to shared modules require updating all consumers

---

*This rule is referenced by 20_trent_tasks.md (task completion), 22_trent_planning.md (planning), 03_code_review.md (review), 23_trent_qa.md (quality gates), and 24_trent_workflow.md (task expansion).*
